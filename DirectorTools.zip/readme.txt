Install director tools, including:
	- SlackerTracker
<?php

function template_main()
{
	echo '<iframe src="/wiki/" width="1000px" height="800px" frameborder="0" />';
}

?>

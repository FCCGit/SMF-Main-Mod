<?php
if (!defined('SMF'))
        die('Hacking attempt...');

function Render()
{
        global $txt, $scripturl, $modSettings, $user_info, $context, $smcFunc;

        loadTemplate('Wiki');

//echo '<iframe src="/wiki/" width="1000px" height="800px" frameborder="0" />';
}
?>
